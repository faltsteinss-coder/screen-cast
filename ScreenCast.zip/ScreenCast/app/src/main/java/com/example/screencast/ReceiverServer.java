package com.example.screencast;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.media.MediaCodec;
import android.media.MediaFormat;
import android.util.Log;
import android.view.Surface;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;

/** TCP-сервер: принимает пакеты и декодирует их на экран и в динамики. */
final class ReceiverServer extends Thread {
    interface Listener {
        void onVideoSize(ReceiverServer from, int width, int height);
        void onDisconnected(ReceiverServer from, String message);
    }

    private static final String TAG = "ReceiverServer";

    private final Surface surface;
    private final int pin;
    private final Listener listener;
    private volatile boolean running = true;
    private ServerSocket server;
    private Socket client;

    ReceiverServer(Surface surface, int pin, Listener listener) {
        super("receiver");
        this.surface = surface;
        this.pin = pin;
        this.listener = listener;
    }

    /** Останавливает сервер и ждёт освобождения декодера до уничтожения Surface. */
    void shutdown() {
        synchronized (this) {
            running = false;
            try { if (server != null) server.close(); } catch (IOException ignored) { }
            try { if (client != null) client.close(); } catch (IOException ignored) { }
        }
        try { join(2000); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }

    @Override
    public void run() {
        try {
            ServerSocket ss = new ServerSocket();
            synchronized (this) {
                if (!running) { ss.close(); return; }
                server = ss;
            }
            ss.setReuseAddress(true);
            ss.bind(new InetSocketAddress(Protocol.PORT));
            while (running) {
                try (Socket s = ss.accept()) {
                    synchronized (this) {
                        if (!running) return;
                        client = s;
                    }
                    serve(s);
                } catch (IOException | RuntimeException e) {
                    if (!running) return;
                    Log.w(TAG, "client", e);
                    listener.onDisconnected(this, "Соединение завершено");
                }
            }
        } catch (IOException e) {
            if (running) listener.onDisconnected(this, "Не удалось открыть порт: " + e.getMessage());
        }
    }

    private void serve(Socket s) throws IOException {
        s.setSoTimeout(5000);
        s.setTcpNoDelay(true);
        DataInputStream in = new DataInputStream(s.getInputStream());
        DataOutputStream out = new DataOutputStream(s.getOutputStream());
        if (in.readInt() != Protocol.MAGIC) return;
        int version = in.readInt();
        int code = in.readInt();
        if (version != Protocol.VERSION) {
            out.writeByte(Protocol.REPLY_BAD_VERSION);
            return;
        }
        if (code != pin) {
            // Задержка затрудняет подбор кода
            try { Thread.sleep(2000); } catch (InterruptedException e) { return; }
            out.writeByte(Protocol.REPLY_BAD_PIN);
            return;
        }
        out.writeByte(Protocol.REPLY_OK);
        out.flush();
        s.setSoTimeout(10000);

        VideoDecoder video = null;
        AudioPlayer audio = null;
        try {
            while (running) {
                Protocol.Packet p = Protocol.read(in);
                if (p.type == Protocol.VIDEO_CONFIG) {
                    ByteBuffer b = ByteBuffer.wrap(p.data);
                    int w = b.getInt();
                    int h = b.getInt();
                    byte[] config = new byte[b.remaining()];
                    b.get(config);
                    if (video != null) video.release();
                    video = null;
                    listener.onVideoSize(this, w, h);
                    video = new VideoDecoder(surface, w, h);
                    video.feed(config, 0, MediaCodec.BUFFER_FLAG_CODEC_CONFIG);
                } else if (p.type == Protocol.VIDEO_FRAME && video != null) {
                    video.feed(p.data, p.pts, 0);
                } else if (p.type == Protocol.AUDIO) {
                    if (audio == null) audio = new AudioPlayer();
                    audio.play(p.data);
                }
            }
        } finally {
            if (video != null) video.release();
            if (audio != null) audio.release();
        }
    }

    private static final class VideoDecoder {
        private final MediaCodec codec;
        private final Thread output;
        private volatile boolean decoding = true;

        VideoDecoder(Surface surface, int w, int h) throws IOException {
            codec = MediaCodec.createDecoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
            try {
                MediaFormat f = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h);
                f.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 2 * 1024 * 1024);
                if (android.os.Build.VERSION.SDK_INT >= 30) {
                    f.setInteger(MediaFormat.KEY_LOW_LATENCY, 1);
                }
                codec.configure(f, surface, null, 0);
                codec.start();
            } catch (RuntimeException e) {
                codec.release();
                throw e;
            }
            output = new Thread(this::render, "render");
            output.start();
        }

        void feed(byte[] data, long pts, int flags) throws IOException {
            for (int attempt = 0; attempt < 100; attempt++) {
                int i = codec.dequeueInputBuffer(20_000);
                if (i < 0) continue;
                ByteBuffer b = codec.getInputBuffer(i);
                b.clear();
                if (data.length > b.remaining()) throw new IOException("Слишком большой кадр");
                b.put(data);
                codec.queueInputBuffer(i, 0, data.length, pts, flags);
                return;
            }
            throw new IOException("Декодер не отвечает");
        }

        private void render() {
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            try {
                while (decoding) {
                    int i = codec.dequeueOutputBuffer(info, 20_000);
                    if (i >= 0) codec.releaseOutputBuffer(i, true); // показываем сразу
                }
            } catch (IllegalStateException e) {
                Log.w(TAG, "render", e);
            }
        }

        void release() {
            decoding = false;
            try { output.join(1000); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            try { codec.stop(); } catch (IllegalStateException ignored) { }
            codec.release();
        }
    }

    /** Звук играет в отдельном потоке, чтобы не тормозить видео. */
    private static final class AudioPlayer {
        private final ArrayBlockingQueue<byte[]> queue = new ArrayBlockingQueue<>(10); // ~200 мс
        private final AudioTrack track;
        private final Thread thread;
        private volatile boolean playing = true;

        AudioPlayer() {
            int min = AudioTrack.getMinBufferSize(Protocol.SAMPLE_RATE,
                    AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT);
            track = new AudioTrack(
                    new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                            .build(),
                    new AudioFormat.Builder()
                            .setSampleRate(Protocol.SAMPLE_RATE)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                            .build(),
                    Math.max(min, 3840 * 4),
                    AudioTrack.MODE_STREAM,
                    android.media.AudioManager.AUDIO_SESSION_ID_GENERATE);
            track.play();
            thread = new Thread(() -> {
                try {
                    while (playing) {
                        byte[] data = queue.poll(100, TimeUnit.MILLISECONDS);
                        if (data != null) track.write(data, 0, data.length);
                    }
                } catch (InterruptedException ignored) { }
            }, "playback");
            thread.start();
        }

        void play(byte[] data) {
            while (!queue.offer(data)) queue.poll(); // выбрасываем самое старое
        }

        void release() {
            playing = false;
            try { track.pause(); } catch (IllegalStateException ignored) { }
            try { thread.join(1000); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            track.release();
        }
    }
}
