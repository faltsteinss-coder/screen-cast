package com.example.screencast;

import android.app.Activity;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Простая вёрстка из кода: вертикальный список элементов. */
final class Ui {
    static int dp(Activity a, int v) {
        return Math.round(v * a.getResources().getDisplayMetrics().density);
    }

    static LinearLayout screen(Activity a) {
        ScrollView scroll = new ScrollView(a);
        scroll.setFillViewport(true);
        scroll.setFitsSystemWindows(true);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        int p = dp(a, 24);
        box.setPadding(p, p, p, p);
        scroll.addView(box);
        a.setContentView(scroll);
        return box;
    }

    static TextView text(LinearLayout box, String value, int sp) {
        TextView t = new TextView(box.getContext());
        t.setText(value);
        t.setTextSize(sp);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, 12, 0, 12);
        box.addView(t, new LinearLayout.LayoutParams(-1, -2));
        return t;
    }

    static Button button(LinearLayout box, String value, Runnable action) {
        Button b = new Button(box.getContext());
        b.setText(value);
        b.setAllCaps(false);
        b.setOnClickListener(v -> action.run());
        box.addView(b, new LinearLayout.LayoutParams(-1, -2));
        return b;
    }

    private Ui() {}
}
