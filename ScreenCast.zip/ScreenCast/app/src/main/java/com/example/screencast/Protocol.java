package com.example.screencast;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * Протокол поверх TCP.
 * Рукопожатие: телефон -> MAGIC, VERSION, PIN; приставка -> 1 байт ответа.
 * Далее пакеты: тип(1) | длина(4) | pts в мкс(8) | данные.
 */
final class Protocol {
    static final int PORT = 47000;
    static final String SERVICE_TYPE = "_screencast._tcp.";

    static final int MAGIC = 0x53435354; // "SCST"
    static final int VERSION = 1;

    static final byte REPLY_OK = 0;
    static final byte REPLY_BAD_PIN = 1;
    static final byte REPLY_BAD_VERSION = 2;

    static final byte VIDEO_CONFIG = 1; // ширина(4), высота(4), SPS/PPS
    static final byte VIDEO_FRAME = 2;  // H.264
    static final byte AUDIO = 3;        // PCM 16 бит, стерео, 48 кГц
    static final byte PING = 4;

    static final int SAMPLE_RATE = 48000;
    static final int MAX_PAYLOAD = 8 * 1024 * 1024;

    static final class Packet {
        final byte type;
        final long pts;
        final byte[] data;
        final boolean keyFrame; // используется только отправителем

        Packet(byte type, long pts, byte[] data, boolean keyFrame) {
            this.type = type;
            this.pts = pts;
            this.data = data;
            this.keyFrame = keyFrame;
        }
    }

    static void write(DataOutputStream out, Packet p) throws IOException {
        out.writeByte(p.type);
        out.writeInt(p.data.length);
        out.writeLong(p.pts);
        out.write(p.data);
        out.flush();
    }

    static Packet read(DataInputStream in) throws IOException {
        byte type = in.readByte();
        int length = in.readInt();
        long pts = in.readLong();
        if (length < 0 || length > MAX_PAYLOAD) {
            throw new IOException("Неверная длина пакета: " + length);
        }
        byte[] data = new byte[length];
        in.readFully(data);
        return new Packet(type, pts, data, false);
    }

    private Protocol() {}
}
