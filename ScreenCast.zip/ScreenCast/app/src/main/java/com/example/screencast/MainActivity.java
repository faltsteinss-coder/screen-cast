package com.example.screencast;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout box = Ui.screen(this);
        Ui.text(box, "ScreenCast", 28);
        Ui.text(box, "Выберите роль этого устройства", 16);
        Ui.button(box, "Передавать экран (телефон)",
                () -> startActivity(new Intent(this, SenderActivity.class)));
        Ui.button(box, "Принимать трансляцию (ТВ-приставка)",
                () -> startActivity(new Intent(this, ReceiverActivity.class))).requestFocus();
    }
}
