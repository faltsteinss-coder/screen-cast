package com.example.screencast;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.Surface;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/** Фоновый сервис: захват экрана и звука, кодирование и отправка. */
public class CastService extends Service {
    static volatile String status = "";
    static volatile boolean running;

    private static final String TAG = "CastService";
    private static final String ACTION_STOP = "stop";
    private static final String CHANNEL = "cast";
    private static final int MAX_QUEUE = 60;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final LinkedBlockingQueue<Protocol.Packet> queue = new LinkedBlockingQueue<>();

    private volatile boolean active;
    private volatile boolean waitKeyFrame;
    private volatile long writeStarted;
    private Socket socket;
    private MediaProjection projection;
    private VirtualDisplay display;
    private VideoEncoder video;
    private Thread audioThread;
    private PowerManager.WakeLock wakeLock;
    private boolean hd, sound;
    private int width, height;

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || ACTION_STOP.equals(intent.getAction())) {
            finish("Трансляция остановлена");
            return START_NOT_STICKY;
        }
        if (active) return START_NOT_STICKY;

        // Порядок важен: сначала foreground, потом getMediaProjection (Android 14+)
        Notification n = notification();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(1, n);
        }
        active = true;
        running = true;
        status = "Подключение…";
        hd = intent.getBooleanExtra("hd", true);
        sound = intent.getBooleanExtra("sound", false);

        try {
            MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            Intent data = intent.getParcelableExtra("data");
            projection = m.getMediaProjection(intent.getIntExtra("result", 0), data);
            projection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() { finish("Захват экрана остановлен системой"); }
            }, main);
        } catch (RuntimeException e) {
            fail(e);
            return START_NOT_STICKY;
        }

        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "screencast:cast");
        wakeLock.acquire(6 * 60 * 60 * 1000L);

        String host = intent.getStringExtra("host");
        int pin = intent.getIntExtra("pin", 0);
        new Thread(() -> network(host, pin), "network").start();
        return START_NOT_STICKY;
    }

    private void network(String host, int pin) {
        Socket s = new Socket();
        try {
            synchronized (this) {
                if (!active) return;
                socket = s;
            }
            s.connect(new InetSocketAddress(host, Protocol.PORT), 5000);
            s.setTcpNoDelay(true);
            s.setSoTimeout(5000);
            DataOutputStream out = new DataOutputStream(s.getOutputStream());
            out.writeInt(Protocol.MAGIC);
            out.writeInt(Protocol.VERSION);
            out.writeInt(pin);
            out.flush();
            byte reply = new DataInputStream(s.getInputStream()).readByte();
            if (reply != Protocol.REPLY_OK) {
                String reason = reply == Protocol.REPLY_BAD_PIN
                        ? "Неверный код" : "Разные версии приложения";
                main.post(() -> finish(reason));
                return;
            }
            main.post(this::startCapture);
            main.postDelayed(watchdog, 2000);

            while (active) {
                Protocol.Packet p = queue.poll(2, TimeUnit.SECONDS);
                if (p == null) p = new Protocol.Packet(Protocol.PING, 0, new byte[0], false);
                writeStarted = System.currentTimeMillis();
                Protocol.write(out, p);
                writeStarted = 0;
            }
        } catch (IOException | InterruptedException e) {
            Log.w(TAG, "network", e);
            main.post(() -> finish("Соединение прервано: " + e.getMessage()));
        } finally {
            close(s);
        }
    }

    /** Разрывает соединение, если запись «зависла» (приставка пропала из сети). */
    private final Runnable watchdog = new Runnable() {
        @Override
        public void run() {
            if (!active) return;
            long t = writeStarted;
            if (t != 0 && System.currentTimeMillis() - t > 8000) {
                finish("Приставка не отвечает");
            } else {
                main.postDelayed(this, 2000);
            }
        }
    };

    /** При медленной сети отбрасываем кадры, чтобы задержка не росла. */
    private synchronized void offer(Protocol.Packet p) {
        if (!active) return;
        if (p.type == Protocol.VIDEO_FRAME) {
            if (waitKeyFrame && !p.keyFrame) return;
            if (queue.size() > MAX_QUEUE) {
                queue.removeIf(q -> q.type != Protocol.VIDEO_CONFIG);
                if (!p.keyFrame) {
                    waitKeyFrame = true;
                    if (video != null) video.requestKeyFrame();
                    return;
                }
            }
            waitKeyFrame = false;
        } else if (p.type == Protocol.AUDIO && queue.size() > MAX_QUEUE) {
            return;
        }
        queue.add(p);
    }

    private void startCapture() {
        if (!active) return;
        try {
            int[] size = captureSize();
            width = size[0];
            height = size[1];
            video = new VideoEncoder(width, height);
            display = projection.createVirtualDisplay("ScreenCast", width, height,
                    getResources().getDisplayMetrics().densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, video.surface, null, null);
            video.start();
            if (sound && Build.VERSION.SDK_INT >= 29) startAudio();
            status = "Идёт трансляция " + width + "×" + height;
        } catch (IOException | RuntimeException e) {
            fail(e);
        }
    }

    /** Размер экрана, уменьшенный до выбранного качества и кратный 16. */
    private int[] captureSize() {
        DisplayMetrics m = new DisplayMetrics();
        ((DisplayManager) getSystemService(DISPLAY_SERVICE))
                .getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(m);
        int limit = hd ? 1920 : 1280;
        float scale = Math.min(1f, (float) limit / Math.max(m.widthPixels, m.heightPixels));
        int w = Math.round(m.widthPixels * scale / 16f) * 16;
        int h = Math.round(m.heightPixels * scale / 16f) * 16;
        return new int[]{w, h};
    }

    /** Поворот экрана: пересоздаём кодировщик под новый размер. */
    @Override
    public void onConfigurationChanged(Configuration config) {
        super.onConfigurationChanged(config);
        if (!active || display == null) return;
        int[] size = captureSize();
        if (size[0] == width && size[1] == height) return;
        try {
            display.setSurface(null);
            video.stop();
            width = size[0];
            height = size[1];
            VideoEncoder next = new VideoEncoder(width, height);
            synchronized (this) {
                queue.removeIf(q -> q.type != Protocol.AUDIO);
                waitKeyFrame = false;
                video = next;
            }
            display.resize(width, height, getResources().getDisplayMetrics().densityDpi);
            display.setSurface(next.surface);
            next.start();
            status = "Идёт трансляция " + width + "×" + height;
        } catch (IOException | RuntimeException e) {
            fail(e);
        }
    }

    private final class VideoEncoder {
        private final MediaCodec codec;
        final Surface surface;
        private final int w, h;
        private volatile boolean encoding = true;
        private Thread thread;

        VideoEncoder(int w, int h) throws IOException {
            this.w = w;
            this.h = h;
            codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
            MediaFormat f = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h);
            f.setInteger(MediaFormat.KEY_COLOR_FORMAT,
                    MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
            f.setInteger(MediaFormat.KEY_BIT_RATE, hd ? 10_000_000 : 4_000_000);
            f.setInteger(MediaFormat.KEY_FRAME_RATE, 30);
            f.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2);
            f.setLong(MediaFormat.KEY_REPEAT_PREVIOUS_FRAME_AFTER, 100_000);
            try {
                codec.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
                surface = codec.createInputSurface();
            } catch (RuntimeException e) {
                codec.release();
                throw e;
            }
        }

        void start() {
            codec.start();
            thread = new Thread(this::drain, "video");
            thread.start();
        }

        private void drain() {
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            try {
                while (encoding) {
                    int i = codec.dequeueOutputBuffer(info, 50_000);
                    if (i < 0) continue;
                    ByteBuffer b = codec.getOutputBuffer(i);
                    byte[] data = new byte[info.size];
                    b.position(info.offset);
                    b.get(data);
                    codec.releaseOutputBuffer(i, false);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                        byte[] config = ByteBuffer.allocate(8 + data.length)
                                .putInt(w).putInt(h).put(data).array();
                        offer(new Protocol.Packet(Protocol.VIDEO_CONFIG, 0, config, false));
                    } else if (data.length > 0) {
                        boolean key = (info.flags & MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0;
                        offer(new Protocol.Packet(Protocol.VIDEO_FRAME,
                                info.presentationTimeUs, data, key));
                    }
                }
            } catch (RuntimeException e) {
                if (encoding) main.post(() -> fail(e));
            }
        }

        void requestKeyFrame() {
            try {
                Bundle b = new Bundle();
                b.putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0);
                codec.setParameters(b);
            } catch (IllegalStateException ignored) { }
        }

        void stop() {
            encoding = false;
            join(thread);
            try { codec.stop(); } catch (IllegalStateException ignored) { }
            codec.release();
            surface.release();
        }
    }

    /** Захват системного звука. Часть приложений его запрещает — тогда будет тишина. */
    @android.annotation.TargetApi(29)
    @android.annotation.SuppressLint("MissingPermission")
    private void startAudio() {
        AudioRecord record;
        try {
            AudioPlaybackCaptureConfiguration capture =
                    new AudioPlaybackCaptureConfiguration.Builder(projection)
                            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                            .addMatchingUsage(AudioAttributes.USAGE_GAME)
                            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                            .build();
            AudioFormat format = new AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(Protocol.SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                    .build();
            int min = AudioRecord.getMinBufferSize(Protocol.SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT);
            record = new AudioRecord.Builder()
                    .setAudioFormat(format)
                    .setBufferSizeInBytes(Math.max(min, 3840) * 2)
                    .setAudioPlaybackCaptureConfig(capture)
                    .build();
            record.startRecording();
        } catch (RuntimeException e) {
            Log.w(TAG, "Звук недоступен", e); // продолжаем без звука
            return;
        }
        audioThread = new Thread(() -> {
            byte[] buffer = new byte[3840]; // 20 мс
            try {
                while (active) {
                    int n = record.read(buffer, 0, buffer.length);
                    if (n < 0) break;
                    if (n == 0) continue;
                    byte[] data = java.util.Arrays.copyOf(buffer, n);
                    offer(new Protocol.Packet(Protocol.AUDIO, System.nanoTime() / 1000, data, false));
                }
            } finally {
                record.release();
            }
        }, "audio");
        audioThread.start();
    }

    private Notification notification() {
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager.class).createNotificationChannel(
                    new NotificationChannel(CHANNEL, "Трансляция", NotificationManager.IMPORTANCE_LOW));
            b = new Notification.Builder(this, CHANNEL);
        } else {
            b = new Notification.Builder(this);
        }
        PendingIntent stop = PendingIntent.getService(this, 0,
                new Intent(this, CastService.class).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE);
        return b.setSmallIcon(R.drawable.ic_cast)
                .setContentTitle("Экран транслируется на ТВ")
                .setContentText("Нажмите, чтобы остановить")
                .setContentIntent(stop)
                .setOngoing(true)
                .build();
    }

    private void fail(Exception e) {
        Log.e(TAG, "Ошибка", e);
        finish("Ошибка: " + e.getMessage());
    }

    /** Вызывается в главном потоке. */
    private void finish(String message) {
        if (active) status = message;
        release();
        stopSelf();
    }

    private void release() {
        synchronized (this) {
            if (!active) return;
            active = false;
            close(socket);
        }
        running = false;
        main.removeCallbacks(watchdog);
        join(audioThread);
        if (display != null) display.release();
        if (video != null) video.stop();
        if (projection != null) projection.stop();
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        queue.clear();
        display = null;
        video = null;
        projection = null;
    }

    @Override
    public void onDestroy() {
        if (active) status = "Трансляция остановлена";
        release();
        super.onDestroy();
    }

    private static void join(Thread t) {
        if (t == null) return;
        try { t.join(1000); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }

    private static void close(Socket s) {
        if (s == null) return;
        try { s.close(); } catch (IOException ignored) { }
    }
}
