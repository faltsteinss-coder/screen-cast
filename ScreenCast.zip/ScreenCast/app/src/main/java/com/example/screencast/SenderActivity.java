package com.example.screencast;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SenderActivity extends Activity {
    private static final int REQ_PERMISSIONS = 1;
    private static final int REQ_PROJECTION = 2;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ArrayDeque<NsdServiceInfo> resolveQueue = new ArrayDeque<>();
    private final Set<String> found = new HashSet<>();
    private boolean resolving;

    private NsdManager nsd;
    private NsdManager.DiscoveryListener discovery;
    private LinearLayout devices;
    private EditText ip, pin;
    private CheckBox sound;
    private RadioButton hd;
    private TextView status;
    private Button stop;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        SharedPreferences prefs = getSharedPreferences("sender", MODE_PRIVATE);
        LinearLayout box = Ui.screen(this);
        Ui.text(box, "Передача экрана", 24);
        Ui.text(box, "Найденные приставки (нажмите, чтобы выбрать):", 14);
        devices = new LinearLayout(this);
        devices.setOrientation(LinearLayout.VERTICAL);
        box.addView(devices, new LinearLayout.LayoutParams(-1, -2));

        ip = field(box, "IP-адрес приставки", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        ip.setText(prefs.getString("ip", ""));
        pin = field(box, "Код с экрана телевизора", InputType.TYPE_CLASS_NUMBER);
        pin.setText(prefs.getString("pin", ""));

        RadioGroup quality = new RadioGroup(this);
        RadioButton sd = radio(quality, "720p, 4 Мбит/с (слабый Wi-Fi)");
        hd = radio(quality, "1080p, 10 Мбит/с");
        quality.check(prefs.getBoolean("hd", true) ? hd.getId() : sd.getId());
        box.addView(quality, new LinearLayout.LayoutParams(-1, -2));

        sound = new CheckBox(this);
        sound.setText("Передавать звук (Android 10+)");
        sound.setEnabled(Build.VERSION.SDK_INT >= 29);
        sound.setChecked(Build.VERSION.SDK_INT >= 29);
        box.addView(sound, new LinearLayout.LayoutParams(-1, -2));

        Ui.button(box, "Начать трансляцию", this::begin);
        stop = Ui.button(box, "Остановить", () -> stopService(new Intent(this, CastService.class)));
        status = Ui.text(box, "", 16);
        nsd = (NsdManager) getSystemService(NSD_SERVICE);
    }

    private EditText field(LinearLayout box, String hint, int type) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setInputType(type);
        e.setSingleLine(true);
        box.addView(e, new LinearLayout.LayoutParams(-1, -2));
        return e;
    }

    private RadioButton radio(RadioGroup group, String label) {
        RadioButton r = new RadioButton(this);
        r.setId(android.view.View.generateViewId());
        r.setText(label);
        group.addView(r);
        return r;
    }

    private void begin() {
        String host = ip.getText().toString().trim();
        String code = pin.getText().toString().trim();
        if (host.isEmpty() || !code.matches("\\d{4}")) {
            status.setText("Укажите IP-адрес и 4-значный код");
            return;
        }
        getSharedPreferences("sender", MODE_PRIVATE).edit()
                .putString("ip", host).putString("pin", code)
                .putBoolean("hd", hd.isChecked()).apply();

        List<String> need = new ArrayList<>();
        if (sound.isChecked() && missing(Manifest.permission.RECORD_AUDIO)) {
            need.add(Manifest.permission.RECORD_AUDIO);
        }
        if (Build.VERSION.SDK_INT >= 33 && missing(Manifest.permission.POST_NOTIFICATIONS)) {
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (need.isEmpty()) askProjection();
        else requestPermissions(need.toArray(new String[0]), REQ_PERMISSIONS);
    }

    private boolean missing(String permission) {
        return checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int request, String[] permissions, int[] results) {
        // Без разрешений на звук и уведомления видео всё равно можно передавать
        if (request == REQ_PERMISSIONS) askProjection();
    }

    private void askProjection() {
        MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(m.createScreenCaptureIntent(), REQ_PROJECTION);
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        if (request != REQ_PROJECTION) return;
        if (result != RESULT_OK || data == null) {
            status.setText("Захват экрана не разрешён");
            return;
        }
        Intent i = new Intent(this, CastService.class)
                .putExtra("result", result)
                .putExtra("data", data)
                .putExtra("host", ip.getText().toString().trim())
                .putExtra("pin", Integer.parseInt(pin.getText().toString().trim()))
                .putExtra("hd", hd.isChecked())
                .putExtra("sound", sound.isChecked()
                        && !missing(Manifest.permission.RECORD_AUDIO));
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);
    }

    private final Runnable refresh = new Runnable() {
        @Override
        public void run() {
            status.setText(CastService.status);
            stop.setEnabled(CastService.running);
            main.postDelayed(this, 500);
        }
    };

    @Override
    protected void onStart() {
        super.onStart();
        main.post(refresh);
        startDiscovery();
    }

    @Override
    protected void onStop() {
        main.removeCallbacks(refresh);
        if (discovery != null) {
            try { nsd.stopServiceDiscovery(discovery); } catch (IllegalArgumentException ignored) { }
            discovery = null;
        }
        super.onStop();
    }

    private void startDiscovery() {
        devices.removeAllViews();
        found.clear();
        resolveQueue.clear();
        discovery = new NsdManager.DiscoveryListener() {
            @Override public void onDiscoveryStarted(String type) { }
            @Override public void onDiscoveryStopped(String type) { }
            @Override public void onStartDiscoveryFailed(String type, int error) { }
            @Override public void onStopDiscoveryFailed(String type, int error) { }
            @Override public void onServiceLost(NsdServiceInfo info) { }
            @Override public void onServiceFound(NsdServiceInfo info) {
                main.post(() -> {
                    resolveQueue.add(info);
                    resolveNext();
                });
            }
        };
        nsd.discoverServices(Protocol.SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, discovery);
    }

    /** NsdManager умеет разрешать только одну службу за раз. */
    private void resolveNext() {
        if (resolving || resolveQueue.isEmpty()) return;
        resolving = true;
        nsd.resolveService(resolveQueue.poll(), new NsdManager.ResolveListener() {
            @Override public void onResolveFailed(NsdServiceInfo info, int error) {
                main.post(() -> { resolving = false; resolveNext(); });
            }
            @Override public void onServiceResolved(NsdServiceInfo info) {
                main.post(() -> {
                    resolving = false;
                    if (info.getHost() != null) {
                        String host = info.getHost().getHostAddress();
                        if (found.add(host)) {
                            Ui.button(devices, info.getServiceName() + "  (" + host + ")",
                                    () -> ip.setText(host));
                        }
                    }
                    resolveNext();
                });
            }
        });
    }
}
