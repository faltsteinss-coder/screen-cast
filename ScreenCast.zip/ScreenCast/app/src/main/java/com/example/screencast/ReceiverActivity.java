package com.example.screencast;

import android.app.Activity;
import android.graphics.Color;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.security.SecureRandom;
import java.util.Collections;

/** Экран ТВ-приставки: показывает код, принимает и выводит трансляцию. */
public class ReceiverActivity extends Activity
        implements SurfaceHolder.Callback, ReceiverServer.Listener {
    private FrameLayout root;
    private SurfaceView surface;
    private TextView info;
    private ReceiverServer server;
    private NsdManager nsd;
    private NsdManager.RegistrationListener registration;
    private int pin;
    private int videoWidth, videoHeight;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        pin = 1000 + new SecureRandom().nextInt(9000);
        nsd = (NsdManager) getSystemService(NSD_SERVICE);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        surface = new SurfaceView(this);
        root.addView(surface, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        info = new TextView(this);
        info.setTextSize(28);
        info.setTextColor(Color.WHITE);
        info.setBackgroundColor(Color.BLACK);
        info.setGravity(Gravity.CENTER);
        root.addView(info, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        root.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> {
            if (r - l != or - ol || b - t != ob - ot) v.post(this::fitVideo);
        });
        surface.getHolder().addCallback(this);
    }

    @Override
    public void onWindowFocusChanged(boolean focus) {
        super.onWindowFocusChanged(focus);
        if (focus) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        showWaiting(null);
        server = new ReceiverServer(holder.getSurface(), pin, this);
        server.start();
        register();
    }

    @Override public void surfaceChanged(SurfaceHolder h, int format, int w, int ht) { }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        if (registration != null) {
            try { nsd.unregisterService(registration); } catch (IllegalArgumentException ignored) { }
            registration = null;
        }
        if (server != null) {
            server.shutdown();
            server = null;
        }
    }

    private void register() {
        NsdServiceInfo service = new NsdServiceInfo();
        service.setServiceName("ScreenCast " + Build.MODEL);
        service.setServiceType(Protocol.SERVICE_TYPE);
        service.setPort(Protocol.PORT);
        registration = new NsdManager.RegistrationListener() {
            @Override public void onServiceRegistered(NsdServiceInfo i) { }
            @Override public void onRegistrationFailed(NsdServiceInfo i, int error) { }
            @Override public void onServiceUnregistered(NsdServiceInfo i) { }
            @Override public void onUnregistrationFailed(NsdServiceInfo i, int error) { }
        };
        nsd.registerService(service, NsdManager.PROTOCOL_DNS_SD, registration);
    }

    private void showWaiting(String message) {
        String text = "Ожидание телефона…\n\nIP: " + localAddresses() + "\nКод: " + pin;
        if (message != null) text += "\n\n" + message;
        info.setText(text);
        info.setVisibility(View.VISIBLE);
    }

    private static String localAddresses() {
        StringBuilder s = new StringBuilder();
        try {
            for (NetworkInterface n : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!n.isUp() || n.isLoopback()) continue;
                for (InetAddress a : Collections.list(n.getInetAddresses())) {
                    if (a instanceof Inet4Address) {
                        if (s.length() > 0) s.append(", ");
                        s.append(a.getHostAddress());
                    }
                }
            }
        } catch (SocketException ignored) { }
        return s.length() > 0 ? s.toString() : "нет подключения к сети";
    }

    /** Вписывает видео в экран с сохранением пропорций. */
    private void fitVideo() {
        if (videoWidth == 0 || root.getWidth() == 0) return;
        float scale = Math.min((float) root.getWidth() / videoWidth,
                (float) root.getHeight() / videoHeight);
        surface.setLayoutParams(new FrameLayout.LayoutParams(
                Math.round(videoWidth * scale), Math.round(videoHeight * scale), Gravity.CENTER));
    }

    @Override
    public void onVideoSize(ReceiverServer from, int width, int height) {
        runOnUiThread(() -> {
            if (from != server) return;
            videoWidth = width;
            videoHeight = height;
            fitVideo();
            info.setVisibility(View.GONE);
        });
    }

    @Override
    public void onDisconnected(ReceiverServer from, String message) {
        runOnUiThread(() -> {
            if (from == server) showWaiting(message);
        });
    }
}
